package com.milos.financex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancexApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancexApplication.class, args);
	}

}
